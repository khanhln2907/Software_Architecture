
local system = require 'pandoc.system'


function CodeBlock(el)                      -- el = CodeBlock Element

  for idx,val in pairs(el.classes) do       -- Iterates e.g. ```{ .aclass .matplotlib .otherclass }

    if val == "matplotlib" then

      local f = io.open('./res/mpl.py', 'w')
      f:write(el.text .. '\nplt.savefig("./res/mpl.svg")')     -- el.text holds code
      f:close()

      os.execute('python3 ./res/mpl.py')
      
      return pandoc.Para({pandoc.Image('', './res/mpl.svg')})  -- replace CodeBlock with Image

    end

  end

end

-- Notes:
-- pandoc.Para means "Paragraph" (two newlines in Markdown) 

-- Call as 
-- pandoc --lua-filter pandoc-filter-v1.lua -o demo.html -s demo.md

-- Q: How to generate more than one file?


