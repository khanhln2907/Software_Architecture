-- Pandoc Filter to convert code blocks to diagrams
-- Lua-Filter Documentation: https://pandoc.org/lua-filters.html


-- Import dependencies
---------------------------------------------------
local system = require 'pandoc.system'


-- Constants
---------------------------------------------------
local PY_EXT  = 'py'
local R_EXT = 'R'
local SVG_EXT = 'svg'
local HTML_EXT = 'html'

local DIADIR  = './res/'


-- Templates
---------------------------------------------------
local PY_T = 'python3 %s'
local R_T  = 'R < %s --no-save'

local MATPLOTLIB_T = [[
import matplotlib.pyplot as plt
%s
plt.savefig('%s',)
]]

local BOKEH_T = [[
from bokeh.io import export, save
from bokeh.resources import CDN
%s
save(plt, filename="%s", resources=CDN)
]]

local PLOTLY_PY_T = [[
import plotly.graph_objects as go
%s
__currplot = next(obj for obj in globals().values() if type(obj) == go.Figure)
__currplot.write_html("%s")
]]

local GGPLOT2_T = [[
library(ggplot2)
%s
ggsave("%s", plot = last_plot(), width=%s, height=%s)
]]


-- Plotter Map
---------------------------------------------------
local PLOT_MAP = {
  -- plotter    = command,   extra code,        file extension (in,out)
  matplotlib    = {cmd=PY_T, code=MATPLOTLIB_T, inext=PY_EXT, outext=SVG_EXT },
  bokeh         = {cmd=PY_T, code=BOKEH_T,      inext=PY_EXT, outext=HTML_EXT},
  plotly_python = {cmd=PY_T, code=PLOTLY_PY_T,  inext=PY_EXT, outext=HTML_EXT},
  gglpot2       = {cmd=R_T,  code=GGPLOT2_T,    inext=R_EXT,  outext=SVG_EXT },
}


-- Plotting Function, returns Pandoc Element
---------------------------------------------------
local function plotBlock(el, plotter)
  -- Use element ID as filename or SHA1
  identifier = el.identifier
  if identifier == "" then 
    identifier = pandoc.sha1(el.text)
  end

  local tmppath = DIADIR..identifier..'.'..plotter.inext
  local diapath = DIADIR..identifier..'.'..plotter.outext

  local f = io.open(tmppath, 'w')
  f:write(plotter.code:format(el.text, diapath))
  f:close()
  os.execute(plotter.cmd:format(tmppath))

  if plotter.outext == HTML_EXT then
    local file = io.open(diapath, "rb")
    if not file then return el end
    return pandoc.RawBlock(HTML_EXT, file:read "*a")
  else
    return pandoc.Para({pandoc.Image('', diapath)})
  end
end


-- Converter Function for Code Blocks
---------------------------------------------------
function CodeBlock(el)

  for _,cls in pairs(el.classes) do         -- iterate over class names
    for name,plotter in pairs(PLOT_MAP) do  -- iterate over plotters

      if cls == name then                   -- check for matching class name
        return plotBlock(el, plotter)
      end

    end
  end
end

-- Call as 
-- pandoc --lua-filter pandoc-filter-v5.lua -o demo.html -s demo.md

-- Q: Could you have written this code from the beginning?
