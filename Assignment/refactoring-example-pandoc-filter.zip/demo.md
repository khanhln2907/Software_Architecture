---
title: "Plotting Tests"
author: Emanuel Regnath
css: 
  - https://classless.de/classless.css
---


This is a paragraph.

Here is a normal code block:

```{.python}
x = 13
y = x^2
```



### Plot Test with matplotlib  (Python)

Here is a code block that contains plotting code for the normal distribution. 

```{.python #plot-normaldist .matplotlib caption='Normal Distribution'}
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt

# figure setup
fig, ax = plt.subplots(figsize=(10, 5))

# values
lx = np.arange(-4, 4, 0.01)
ly = st.norm.pdf(lx, 0.0, 1.0)

# plot
ax.plot(lx, ly, label="μ = 0, σ = 1")

plt.legend()
```
 
And another figure showing the normal distribution with different mean and standard deviation:


```{.python #plot-normaldist2 .matplotlib caption='Normal Distribution'}
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt

# figure setup
fig, ax = plt.subplots(figsize=(10, 5))

# values
mu1 = 1.0; sig1 = 0.5
lx = np.arange(-4, 4, 0.05)
ly = st.norm.pdf(lx,mu1,sig1)

# plot
ax.plot(lx, ly, label="μ = 1, σ = 0.5")

plt.legend()
```




### Plot Test with Bokeh (Python)

```{.python .bokeh caption='Move around in the plot by using your mouse.'}
import numpy as np
import scipy.stats as st
from bokeh.plotting import figure

mu1 = 0.0; sig1 = 1.0
lx = np.arange(-4, 4, 0.05)
ly = st.norm.pdf(lx,mu1,sig1)

plt = figure(title="Interactive plotting with Bokeh", sizing_mode="scale_width", plot_width=1000, plot_height=500)

plt.line(lx, ly, legend_label="μ = 0, σ = 1", line_width=2)
```
 



### Plotly Test (Python)

```{.python .plotly_python }
import numpy as np
import scipy.stats as st
import pandas as pd
import plotly.express as px

mu1 = 0.0; sig1 = 1.0
lx = np.arange(-4, 4, 0.05)
ly = st.norm.pdf(lx,mu1,sig1)

df = pd.DataFrame(dict(values=lx, probability=ly))
fig = px.line(df, x='values', y='probability')
```


### UML Diagrams

```plantuml
class Person{
  +name: String
  #address: String
  -birthday: Date
}

class Company{
  +name: String
  +address: String
}

class Country{
  +name: String
}

Company "*" o-- "1,*" Person 
Person "1,*" -up-o "1" Country
Person "1" *-right- "2" Hand
Hand "1" *-right- "5" Finger
```

