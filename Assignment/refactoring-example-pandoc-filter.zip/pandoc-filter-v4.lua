-- Pandoc Filter to convert code blocks to diagrams
-- Lua-Filter Documentation: https://pandoc.org/lua-filters.html


-- Import dependencies
---------------------------------------------------
local system = require 'pandoc.system'


-- Constants
---------------------------------------------------
local DIADIR  = './res/'
local PY_EXT  = '.py'
local DIA_EXT = '.svg'


-- Templates
---------------------------------------------------
local MPL_TEMPLATE = [[
import matplotlib.pyplot as plt
%s
plt.savefig('%s',)
]]

local BOKEH_TEMPLATE = [[
from bokeh.io import export, save
from bokeh.resources import CDN
%s
save(plt, filename="%s", resources=CDN)
]]

local PLOTLY_PY_TEMPLATE = [[
import plotly.graph_objects as go
%s
__currplot = next(obj for obj in globals().values() if type(obj) == go.Figure)
__currplot.write_html("%s")
]]

local GGPLOT2_TEMPLATE = [[
library(ggplot2)
%s
ggsave("%s", plot = last_plot(), width=%s, height=%s)
]]

-- Helper Functions
---------------------------------------------------
local function exec_file(fname, text)
  local f = io.open(fname, 'w')
  f:write(text)
  f:close()
  os.execute('python3 '..fname)
end

local function plotBlock(diapath)
  if diapath:sub(-4,-1) == 'html' then       -- decide by output format
    local file = io.open(diapath, "rb")      -- r read mode and b binary mode
    if not file then return el end
    return pandoc.RawBlock('html', file:read "*a")
  else
    return pandoc.Para({pandoc.Image('', diapath)})
  end
end


-- Converter Function for Code Blocks
---------------------------------------------------
function CodeBlock(el)

  -- Use element ID as filename or SHA1
  identifier = el.identifier
  if identifier == "" then 
    identifier = pandoc.sha1(el.text)
  end

  local tmppath = DIADIR..identifier..PY_EXT
  local diapath = DIADIR..identifier

  for idx,val in pairs(el.classes) do

    if val == "matplotlib" then
      exec_file(tmppath, MPL_TEMPLATE:format(el.text, diapath..'.svg'))
      return plotBlock(diapath..'.svg')
    end

    if val == "bokeh" then
      exec_file(tmppath, BOKEH_TEMPLATE:format(el.text, diapath..'.html'))
      return plotBlock(diapath..'.html')
    end

    if val == "plotly_python" then
      exec_file(tmppath, PLOTLY_PY_TEMPLATE:format(el.text, diapath..'.html'))
      return plotBlock(diapath..'.html')
    end

    if val == "ggplot2" then
      exec_file(tmppath, GGPLOT2_TEMPLATE:format(el.text, diapath..'.svg'))
      return plotBlock(diapath..'.svg')
    end
  end
end

-- Call as 
-- pandoc --lua-filter pandoc-filter-v4.lua -o demo.html -s demo.md

-- Q: How to make this code even better?
