-- Pandoc Filter to convert code blocks to diagrams
-- Lua-Filter Documentation: https://pandoc.org/lua-filters.html


-- Import dependencies
local system = require 'pandoc.system'


-- Constants
local MPL_TEMPLATE = [[
import matplotlib.pyplot as plt
%s
plt.savefig('%s',)
]]                        -- "%s" is a placeholder

local DIADIR  = './res/'
local PY_EXT  = '.py'
local DIA_EXT = '.svg'


-- Converter Function for Code Blocks
function CodeBlock(el)

  -- Use element ID as filename or SHA1
  identifier = el.identifier
  if identifier == "" then 
    identifier = pandoc.sha1(el.text)
  end

  for idx,val in pairs(el.classes) do

    if val == "matplotlib" then
      local tmppath = DIADIR..identifier..PY_EXT        -- ".." connects two strings
      local diapath = DIADIR..identifier..DIA_EXT

      local f = io.open(tmppath, 'w')
      f:write(MPL_TEMPLATE:format(el.text, diapath))
      f:close()

      os.execute('python3 '..tmppath)
      return pandoc.Para({pandoc.Image('', diapath)})
    end

  end
end

-- Call as 
-- pandoc --lua-filter pandoc-filter-v2.lua -o demo.html -s demo.md

-- Q: How to generate different plot types?
