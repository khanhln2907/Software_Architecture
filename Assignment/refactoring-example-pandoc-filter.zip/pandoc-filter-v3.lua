-- Pandoc Filter to convert code blocks to diagrams
-- Lua-Filter Documentation: https://pandoc.org/lua-filters.html


-- Import dependencies
local system = require 'pandoc.system'


-- Constants
local PY_EXT  = '.py'
local R_EXT  = 'R'
local DIA_EXT = '.svg'
local DIADIR  = './res/'


-- Templates
local MPL_TEMPLATE = [[
import matplotlib.pyplot as plt
%s
plt.savefig('%s',)
]]


local BOKEH_TEMPLATE = [[
from bokeh.io import export, save
from bokeh.resources import CDN
%s
save(plt, filename="%s", resources=CDN)
]]


local PLOTLY_PY_TEMPLATE = [[
import plotly.graph_objects as go
%s
__currplot = next(obj for obj in globals().values() if type(obj) == go.Figure)
__currplot.write_html("%s")
]]


local GGPLOT2_TEMPLATE = [[
library(ggplot2)
%s
ggsave("%s", plot = last_plot(), width=%s, height=%s)
]]


-- Converter Function for Code Blocks
function CodeBlock(el)

  -- Use element ID as filename or SHA1
  identifier = el.identifier
  if identifier == "" then 
    identifier = pandoc.sha1(el.text)
  end

  for idx,val in pairs(el.classes) do

    -- Matplotlib
    -------------------------------------------------
    if val == "matplotlib" then
      local tmppath = DIADIR..identifier..PY_EXT
      local diapath = DIADIR..identifier..DIA_EXT

      local f = io.open(tmppath, 'w')
      f:write(MPL_TEMPLATE:format(el.text, diapath))
      f:close()

      os.execute('python3 '..tmppath)
      return pandoc.Para({pandoc.Image('', diapath)})
    end

    -- Bokeh (returns HTML)
    -------------------------------------------------
    if val == "bokeh" then
      local tmppath = DIADIR..identifier..PY_EXT
      local diapath = DIADIR..identifier..DIA_EXT

      local f = io.open(tmppath, 'w')
      f:write(BOKEH_TEMPLATE:format(el.text, diapath))
      f:close()

      os.execute('python3 '..tmppath)
      local file = io.open(diapath, "rb") -- r read mode and b binary mode
      if not file then return el end
      return pandoc.RawBlock('html', file:read "*a")
    end

    -- Plotly (returns HTML)
    -------------------------------------------------
    if val == "plotly_python" then
      local tmppath = DIADIR..identifier..PY_EXT
      local diapath = DIADIR..identifier..DIA_EXT

      local f = io.open(tmppath, 'w')
      f:write(PLOTLY_PY_TEMPLATE:format(el.text, diapath))
      f:close()

      os.execute('python3 '..tmppath)
      local file = io.open(diapath, "rb") -- r read mode and b binary mode
      if not file then return el end
      return pandoc.RawBlock('html', file:read "*a")
    end

    -- ggplot2 (returns SVG)
    -------------------------------------------------
    if val == "ggplot2" then
      local tmppath = DIADIR..identifier..R_EXT
      local diapath = DIADIR..identifier..DIA_EXT

      local f = io.open(tmppath, 'w')
      f:write(GGPLOT2_TEMPLATE:format(el.text, diapath))
      f:close()

      os.execute('R < '..tmppath..' --no-save')
      return pandoc.Para({pandoc.Image('', diapath)})
    end
  end
end

-- Call as 
-- pandoc --lua-filter pandoc-filter-v3.lua -o demo.html -s demo.md

-- Q: How to make this code less horrible?
