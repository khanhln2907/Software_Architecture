# config – should contain LightConfig and related classes

# define new subtypes for clarity/type checking
Percent = int






