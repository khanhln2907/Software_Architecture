# Trigger – contains also IntCondition and TriggerManager


class Relation:
    EQUALS='=='
    SMALLER_THAN='<'
    GREATER_THAN='>'

